import { request } from "@/services/http-client";
import { useEffect } from "react";

function HomePage() {
  // const fetchData = async () => {
  //   const response = await request.get("/wc/v3/products");
  //   console.log("RESPONSE ===>", response);
  // };

  return <div>HomePage</div>;
}

export default HomePage;
